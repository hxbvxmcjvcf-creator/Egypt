// lib/core/config/environment_config.dart
//
// Reads --dart-define flags at compile-time.
// flutter run --dart-define=USE_MOCK=true   → MockAuthService
// flutter run --dart-define=USE_MOCK=false  → FirebaseAuthService
//
// Default = true (safe for Google IDX preview)

class EnvironmentConfig {
  EnvironmentConfig._();

  static const bool useMockServices =
      bool.fromEnvironment('USE_MOCK', defaultValue: true);

  static const String appEnv =
      String.fromEnvironment('APP_ENV', defaultValue: 'development');

  static bool get isProduction => appEnv == 'production';
  static bool get isDevelopment => appEnv == 'development';
}
