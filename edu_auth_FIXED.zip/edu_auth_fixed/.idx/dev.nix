{ pkgs, ... }: {
  channel = "stable-24.05";

  packages = [
    pkgs.flutter
    pkgs.android-tools
    pkgs.jdk17
    pkgs.git
    pkgs.curl
    pkgs.unzip
  ];

  env = {
    JAVA_HOME         = "${pkgs.jdk17}";
    FLUTTER_ANALYTICS = "false";
    ANDROID_HOME      = "/home/user/Android/Sdk";
  };

  idx = {
    extensions = [
      "Dart-Code.flutter"
      "Dart-Code.dart-code"
    ];

    workspace = {
      onCreate = {
        flutter-pub-get = "flutter pub get";
      };
      onStart = {
        flutter-pub-get = "flutter pub get";
      };
    };

    previews = {
      enable = true;
      previews = {
        web = {
          command = [
            "flutter"
            "run"
            "--machine"
            "-d" "web-server"
            "--web-port" "$PORT"
            "--web-hostname" "0.0.0.0"
            "--dart-define=USE_MOCK=true"
          ];
          manager = "flutter";
        };
      };
    };
  };
}
